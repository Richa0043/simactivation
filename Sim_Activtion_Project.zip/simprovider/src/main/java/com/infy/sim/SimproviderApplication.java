package com.infy.sim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimproviderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimproviderApplication.class, args);
	}

}
